package Main;

abstract class SmartAppliance {
	String name;
	abstract void perfomeAction();
	public SmartAppliance() {
		this.name="SmartApplianc";
	}
	boolean isOn(boolean isOff) {
		return isOff=false;
	}
	
	boolean isOff(boolean isOn){
		return isOn=false;
		
	}

	
	if (isOn==true) {
		System.out.println("is On");
	}
	else {
		System.out.println("is Off");
	}
}
}
