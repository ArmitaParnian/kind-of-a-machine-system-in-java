package Main;
import java.util.*;
public interface Adjustable {
static void increaseSetting() {
	Scanner reader=new Scanner(System.in);
	float Tempreture=reader.nextFloat();
	float TempretureRiser=reader.nextFloat();
	int [] range = new int[100];
	 TempretureRiser+=Tempreture;
	 System.out.println("Tempreture Rised");
}
static void dreaseSetting() {
	Scanner reader=new Scanner(System.in);
	float Tempreture=reader.nextFloat();
	float TempretureReducer=reader.nextFloat();
	int[] range = new int[100];
	TempretureReducer+=Tempreture;
	System.out.println("Tempreture Reduced");
}
}
