package Main;
import java.util.*;
public class SmartLight extends SmartAppliance{
int [][]brightness=new int[0][100];
void PerformAction() {
	if(isOff(false) == true) {
	System.out.println("the room is lighted up");
	}
	else {
		System.out.println("please light up the room");
	}
}
}
