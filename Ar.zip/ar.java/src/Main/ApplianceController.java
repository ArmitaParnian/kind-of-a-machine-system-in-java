package Main;*;
import java.util.*;
abstract class ApplianceController {
ArrayList<SmartFan> array=new ArrayList<>();

 void PerformAction() {
	
	return PerformAction;
}
}

