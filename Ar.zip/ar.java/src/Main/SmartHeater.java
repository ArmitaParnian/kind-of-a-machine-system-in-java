package Main;

import java.util.Scanner;

public class SmartHeater extends SmartAppliance, implements Adjustable{
	int[] range=new int[2];


	@Override
	void perfomeAction() {
		// TODO Auto-generated method stub
		if(isOff(false)==true) {
		System.out.println("it is turning");
		}
	}
	void increaseSetting() {
		Scanner reader=new Scanner(System.in);
		double[][] increase = new double[0][2];
		double Tempreture = reader.nextDouble();
		while (Tempreture >=0 || Tempreture <= 2) {
		      Tempreture ++;
		      Tempreture++;
		      System.out.println(Tempreture);
		
		
		
		}
	}
	void decreaseSetting() {

		Scanner reader=new Scanner(System.in);
		double[][] increase = new double[0][2];
		double Tempreture = reader.nextDouble();
		while (Tempreture >=0 || Tempreture <= 2) {
		      Tempreture --;
		      Tempreture--;
		      System.out.println(Tempreture);
		
		
	}
}
}